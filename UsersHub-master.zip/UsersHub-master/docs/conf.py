import sphinx_rtd_theme  # noqa

extensions = [
    "sphinx_rtd_theme",
]

project = "UsersHub"
html_theme = "sphinx_rtd_theme"
pygments_style = "sphinx"

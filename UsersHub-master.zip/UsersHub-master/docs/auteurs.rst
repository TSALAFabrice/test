=======
AUTEURS
=======

Parc national des Ecrins
------------------------

* Gil Deluermoz
* Camille Monchicourt
* Gabin Laumond

.. image:: http://geonature.fr/img/logo-pne.jpg
    :target: http://www.ecrins-parcnational.fr
    
Parc national des Cevennes
--------------------------

* Amandine Sahl

.. image:: http://geonature.fr/img/logo-pnc.jpg
    :target: http://www.cevennes-parcnational.fr

Parc national de la Vanoise
---------------------------

* Claire Lagaye
